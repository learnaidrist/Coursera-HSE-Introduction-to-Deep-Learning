
# Getting deeper with Keras
* Tensorflow is a powerful and flexible tool, but coding large neural architectures with it is tedious.
* There are plenty of deep learning toolkits that work on top of it like Slim, TFLearn, Sonnet, Keras.
* Choice is matter of taste and particular task
* We'll be using Keras


```python
import sys
sys.path.append("..")
import grading
```


```python
# use preloaded keras datasets and models
! mkdir -p ~/.keras/datasets
! mkdir -p ~/.keras/models
! ln -s $(realpath ../readonly/keras/datasets/*) ~/.keras/datasets/
! ln -s $(realpath ../readonly/keras/models/*) ~/.keras/models/
```


```python
import numpy as np
from preprocessed_mnist import load_dataset
import keras
X_train, y_train, X_val, y_val, X_test, y_test = load_dataset()
y_train,y_val,y_test = map(keras.utils.np_utils.to_categorical,[y_train,y_val,y_test])
```

    Using TensorFlow backend.



```python
import matplotlib.pyplot as plt
%matplotlib inline
plt.imshow(X_train[0]);
print(y_train[0])
```

    [ 0.  0.  0.  0.  0.  1.  0.  0.  0.  0.]



![png](output_4_1.png)



```python
print(X_train.shape)
print(X_val.shape)
print(X_test.shape)
print('\n')
print(y_train.shape)
print(y_val.shape)
print(y_test.shape)
```

    (50000, 28, 28)
    (10000, 28, 28)
    (10000, 28, 28)
    (50000, 10)
    (10000, 10)
    (10000, 10)


## The pretty keras


```python
import tensorflow as tf
s = tf.InteractiveSession()
```


```python
import keras
from keras.models import Sequential
import keras.layers as ll

model = Sequential(name="mlp")

model.add(ll.InputLayer([28, 28]))

model.add(ll.Flatten())

# network body
model.add(ll.Dense(75))
model.add(ll.Activation('relu'))

model.add(ll.Dense(125))
model.add(ll.Activation('relu'))

model.add(ll.Dense(75))
model.add(ll.Activation('relu'))

# output layer: 10 neurons for each class with softmax
model.add(ll.Dense(10, activation='softmax'))

# categorical_crossentropy is your good old crossentropy
# but applied for one-hot-encoded vectors
model.compile("adam", "categorical_crossentropy", metrics=["accuracy"])
```


```python
model.summary()
```

    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    input_5 (InputLayer)         (None, 28, 28)            0         
    _________________________________________________________________
    flatten_5 (Flatten)          (None, 784)               0         
    _________________________________________________________________
    dense_16 (Dense)             (None, 75)                58875     
    _________________________________________________________________
    activation_12 (Activation)   (None, 75)                0         
    _________________________________________________________________
    dense_17 (Dense)             (None, 125)               9500      
    _________________________________________________________________
    activation_13 (Activation)   (None, 125)               0         
    _________________________________________________________________
    dense_18 (Dense)             (None, 75)                9450      
    _________________________________________________________________
    activation_14 (Activation)   (None, 75)                0         
    _________________________________________________________________
    dense_19 (Dense)             (None, 10)                760       
    =================================================================
    Total params: 78,585
    Trainable params: 78,585
    Non-trainable params: 0
    _________________________________________________________________


### Model interface

Keras models follow __Scikit-learn__'s interface of fit/predict with some notable extensions. Let's take a tour.


```python
# fit(X,y) ships with a neat automatic logging.
#          Highly customizable under the hood.
model.fit(X_train, y_train,
          validation_data=(X_val, y_val), epochs=10);
```

    Train on 50000 samples, validate on 10000 samples
    Epoch 1/10
    50000/50000 [==============================] - 7s - loss: 0.2757 - acc: 0.9173 - val_loss: 0.1423 - val_acc: 0.9572
    Epoch 2/10
    50000/50000 [==============================] - 7s - loss: 0.1204 - acc: 0.9628 - val_loss: 0.1184 - val_acc: 0.9659
    Epoch 3/10
    50000/50000 [==============================] - 7s - loss: 0.0855 - acc: 0.9732 - val_loss: 0.0957 - val_acc: 0.9718
    Epoch 4/10
    50000/50000 [==============================] - 7s - loss: 0.0668 - acc: 0.9786 - val_loss: 0.1052 - val_acc: 0.9701
    Epoch 5/10
    50000/50000 [==============================] - 7s - loss: 0.0554 - acc: 0.9823 - val_loss: 0.1055 - val_acc: 0.9721
    Epoch 6/10
    50000/50000 [==============================] - 7s - loss: 0.0488 - acc: 0.9842 - val_loss: 0.0999 - val_acc: 0.9733
    Epoch 7/10
    50000/50000 [==============================] - 7s - loss: 0.0389 - acc: 0.9872 - val_loss: 0.0969 - val_acc: 0.9751
    Epoch 8/10
    50000/50000 [==============================] - 7s - loss: 0.0375 - acc: 0.9873 - val_loss: 0.1111 - val_acc: 0.9734
    Epoch 9/10
    50000/50000 [==============================] - 7s - loss: 0.0320 - acc: 0.9900 - val_loss: 0.1119 - val_acc: 0.9721
    Epoch 10/10
    50000/50000 [==============================] - 7s - loss: 0.0285 - acc: 0.9908 - val_loss: 0.1104 - val_acc: 0.9731



```python
# estimate probabilities P(y|x)
model.predict_proba(X_val[:2])
```

    2/2 [==============================] - 0s





    array([[  6.17304470e-19,   2.40363535e-10,   1.05189624e-11,
              1.00000000e+00,   8.58985090e-15,   1.34604775e-11,
              2.27274127e-17,   3.00054842e-11,   1.29938491e-10,
              1.89962424e-09],
           [  1.68344418e-12,   2.75098191e-11,   7.09875092e-09,
              1.08627255e-05,   1.92113964e-11,   3.18825161e-10,
              2.83129603e-10,   2.27452761e-11,   9.99989152e-01,
              1.85907911e-08]], dtype=float32)




```python
# Save trained weights
model.save("weights.h5")
```


```python
print("\nLoss, Accuracy = ", model.evaluate(X_test, y_test))
```

     9216/10000 [==========================>...] - ETA: 0s
    Loss, Accuracy =  [0.10402157519632602, 0.9758]


### Whoops!
So far our model is staggeringly inefficient. There is something wring with it. Guess, what?


```python
# Test score...
test_predictions = model.predict_proba(X_test).argmax(axis=-1)
test_answers = y_test.argmax(axis=-1)

test_accuracy = np.mean(test_predictions==test_answers)

print("\nTest accuracy: {} %".format(test_accuracy*100))

assert test_accuracy>=0.92,"Logistic regression can do better!"
assert test_accuracy>=0.975,"Your network can do better!"
print("Great job!")
```

     9856/10000 [============================>.] - ETA: 0s
    Test accuracy: 97.58 %
    Great job!



```python
answer_submitter = grading.Grader("0ybD9ZxxEeea8A6GzH-6CA")
answer_submitter.set_answer("N56DR", test_accuracy)
```


```python
answer_submitter.submit("ssq6554@126.com", "ElEuNjK3zprBIYx3")
```

    Submitted to Coursera platform. See results on assignment page!


## Keras + tensorboard

Remember the interactive graphs from Tensorboard one notebook ago? 

Thing is, Keras can use tensorboard to show you a lot of useful information about the learning progress. Just take a look!


```python
! rm -r /tmp/tboard/**
```


```python
from keras.callbacks import TensorBoard
model.fit(X_train, y_train, validation_data=(X_val, y_val), 
          epochs=10,
          callbacks=[TensorBoard("/tmp/tboard")])
```

    Train on 50000 samples, validate on 10000 samples
    Epoch 1/10
    50000/50000 [==============================] - 7s - loss: 0.0254 - acc: 0.9915 - val_loss: 0.0964 - val_acc: 0.9789
    Epoch 2/10
    50000/50000 [==============================] - 7s - loss: 0.0194 - acc: 0.9939 - val_loss: 0.1124 - val_acc: 0.9758
    Epoch 3/10
    50000/50000 [==============================] - 7s - loss: 0.0227 - acc: 0.9924 - val_loss: 0.1132 - val_acc: 0.9767
    Epoch 4/10
    50000/50000 [==============================] - 7s - loss: 0.0194 - acc: 0.9937 - val_loss: 0.1101 - val_acc: 0.9771
    Epoch 5/10
    50000/50000 [==============================] - 7s - loss: 0.0186 - acc: 0.9941 - val_loss: 0.1171 - val_acc: 0.9753
    Epoch 6/10
    50000/50000 [==============================] - 7s - loss: 0.0205 - acc: 0.9935 - val_loss: 0.1353 - val_acc: 0.9722
    Epoch 7/10
    50000/50000 [==============================] - 7s - loss: 0.0144 - acc: 0.9952 - val_loss: 0.1163 - val_acc: 0.9782
    Epoch 8/10
    50000/50000 [==============================] - 7s - loss: 0.0177 - acc: 0.9945 - val_loss: 0.1306 - val_acc: 0.9773
    Epoch 9/10
    50000/50000 [==============================] - 7s - loss: 0.0162 - acc: 0.9950 - val_loss: 0.1305 - val_acc: 0.9745
    Epoch 10/10
    50000/50000 [==============================] - 7s - loss: 0.0156 - acc: 0.9953 - val_loss: 0.1240 - val_acc: 0.9778





    <keras.callbacks.History at 0x7feb0c0b12b0>



# Tips & tricks

Here are some tips on what you could do. Don't worry, to reach the passing threshold you don't need to try all the ideas listed here, feel free to stop once you reach the 0.975 accuracy mark.

 * __Network size__
   * More neurons, 
   * More layers, ([docs](https://keras.io/))

   * Nonlinearities in the hidden layers
     * tanh, relu, leaky relu, etc
   * Larger networks may take more epochs to train, so don't discard your net just because it could didn't beat the baseline in 5 epochs.


 * __Early Stopping__
   * Training for 100 epochs regardless of anything is probably a bad idea.
   * Some networks converge over 5 epochs, others - over 500.
   * Way to go: stop when validation score is 10 iterations past maximum
     

 * __Faster optimization__
   * rmsprop, nesterov_momentum, adam, adagrad and so on.
     * Converge faster and sometimes reach better optima
     * It might make sense to tweak learning rate/momentum, other learning parameters, batch size and number of epochs


 * __Regularize__ to prevent overfitting
   * Add some L2 weight norm to the loss function, theano will do the rest
     * Can be done manually or via - https://keras.io/regularizers/
   
   
 * __Data augmemntation__ - getting 5x as large dataset for free is a great deal
   * https://keras.io/preprocessing/image/
   * Zoom-in+slice = move
   * Rotate+zoom(to remove black stripes)
   * any other perturbations
   * Simple way to do that (if you have PIL/Image): 
     * ```from scipy.misc import imrotate,imresize```
     * and a few slicing
   * Stay realistic. There's usually no point in flipping dogs upside down as that is not the way you usually see them.
